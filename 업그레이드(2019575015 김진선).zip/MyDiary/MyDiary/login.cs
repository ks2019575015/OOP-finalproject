﻿using System;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace MyDiary
{
    public partial class login : Form
    {
        MySqlConnection connection =
      new MySqlConnection("Server=localhost;Database=diary;Uid=root;Pwd=2019575015;");
        MySqlDataReader myReader;
        public login()
        {
            InitializeComponent();
        }
        
        private void LoginButton_Click(object sender, EventArgs e)
        {
            try
            {
                MySqlCommand selectCommand = new MySqlCommand("select * from member.member_tb where id ='" + this.idBox.Text + "'and pw ='" + this.pwBox.Text + "';", connection);
                                                               // select * from member.member_tb  where id ='id' and pw='pw';
                connection.Open();
                int count = 0;
                myReader = selectCommand.ExecuteReader();

                while (myReader.Read())
                {
                    count = count + 1;
                }

                if (count == 1)
                {
                    this.Hide();
                    main newForm = new main();
                    newForm.Show();
                    Program.ac.MainForm = newForm;
                    this.Close();
                }
                else { MessageBox.Show("아이디와 패스워드를 확인하세요🙄"); }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            start newForm = new start();
            newForm.Show();
            Program.ac.MainForm = newForm;
            this.Close();
        }

        private void signupButton_Click(object sender, EventArgs e)
        {
           this.Hide();
            signup newForm = new signup();
            newForm.Show();
            Program.ac.MainForm = newForm;
            this.Close();
        }
        private void LoginButton_MouseHover(object sender, EventArgs e)
        {
            LoginButton.BackColor = Color.LightGray;
        }

        private void LoginButton_MouseLeave(object sender, EventArgs e)
        {
            LoginButton.BackColor = Color.White;
        }

        private void CancelButton_MouseHover(object sender, EventArgs e)
        {
            CancelButton.BackColor = Color.LightGray;
        }

        private void CancelButton_MouseLeave(object sender, EventArgs e)
        {
            CancelButton.BackColor = Color.White;
        }

        private void signupButton_MouseHover(object sender, EventArgs e)
        {
            signupButton.BackColor = Color.LightGray;
        }

        private void signupButton_MouseLeave(object sender, EventArgs e)
        {
            signupButton.BackColor = Color.White;
        }
    }
}

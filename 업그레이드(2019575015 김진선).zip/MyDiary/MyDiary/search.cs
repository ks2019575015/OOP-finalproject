﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MyDiary
{
    public partial class search : Form
    {
        MySqlConnection connection =
       new MySqlConnection("Server=localhost;Database=diary;Uid=root;Pwd=2019575015;");

        public DataTable GetDBTable(string sql)
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter(sql, connection);
            MySqlCommandBuilder builder = new MySqlCommandBuilder(adapter);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            return dt;
        }

        public search()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection.Open();
            string sql = "select date, title, content from diary_tb where date = '" + this.dateBox.Text + "'";
            DataTable database = GetDBTable(sql);
            dataGridView1.DataSource = database;
            connection.Close();
        }
        

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            main newForm = new main();
            newForm.Show();
            Program.ac.MainForm = newForm;
            this.Close();
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            button1.BackColor = Color.LightGray;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.White;
        }
        private void button2_MouseHover(object sender, EventArgs e)
        {
            button2.BackColor = Color.LightGray;
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            button2.BackColor = Color.White;
        }

        

        
    }
}

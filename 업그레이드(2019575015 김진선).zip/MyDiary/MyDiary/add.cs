﻿using System;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;

namespace MyDiary
{
    public partial class add : Form
    {
        MySqlConnection connection =
        new MySqlConnection("Server=localhost;Database=diary;Uid=root;Pwd=2019575015;");

        public add()
        {
            InitializeComponent();
        }

        private void savebutton_Click(object sender, EventArgs e)
        {
            string insertQuery = "INSERT INTO diary_tb(date,title,content) VALUES('" + this.dateBox.Text + "','" + this.titleBox.Text + "','" + this.ContentBox.Text + "')";
            connection.Open();
            MySqlCommand command = new MySqlCommand(insertQuery, connection);

            try//예외 처리
            {
                if (command.ExecuteNonQuery() == 1) MessageBox.Show("저장완료😉");
                else MessageBox.Show("오류😥");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            connection.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            File.WriteAllText(@"C:\Users\jinsu\Desktop\" + titleBox.Text + ".txt",
                "제목 : " + titleBox.Text + "\n날짜 : " + dateBox.Text + "\n" + ContentBox.Text);
            MessageBox.Show("일기가 내 컴퓨터에 저장되었습니다😎");
        }
        private void button1_MouseHover(object sender, EventArgs e)
        {
            button1.BackColor = Color.DarkGray;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.White;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            main newForm = new main();
            newForm.Show();
            Program.ac.MainForm = newForm;
            this.Close();
        }

        private void savebutton_MouseHover(object sender, EventArgs e)
        {
            savebutton.BackColor = Color.LightGray;
        }

        private void savebutton_MouseLeave(object sender, EventArgs e)
        {
            savebutton.BackColor = Color.White;
        }

        private void button2_MouseHover(object sender, EventArgs e)
        {
            button2.BackColor = Color.LightGray;
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            button2.BackColor = Color.White;
        }

        

        
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MyDiary
{
    public partial class signup : Form
    {
        MySqlConnection connection =
        new MySqlConnection("Server=localhost;Database=member;Uid=root;Pwd=2019575015;");

        public signup()
        {
            InitializeComponent();
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            login newForm = new login();
            newForm.Show();
            Program.ac.MainForm = newForm;
            this.Close();
        }

        private void signupButton_Click(object sender, EventArgs e)
        {
            string insertQuery = "INSERT INTO member_tb(name,id,pw) VALUES('" + this.nameBox.Text + "','" + this.idBox.Text + "','" + this.pwBox.Text + "')";
            connection.Open();
            MySqlCommand command = new MySqlCommand(insertQuery, connection);

            try//예외 처리
            {
                if (command.ExecuteNonQuery() == 1) MessageBox.Show("회원가입 완료😉");
                else MessageBox.Show("오류😥");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            connection.Close();
        }

        private void signupButton_MouseHover(object sender, EventArgs e)
        {
            signupButton.BackColor = Color.LightGray;
        }

        private void signupButton_MouseLeave(object sender, EventArgs e)
        {
            signupButton.BackColor = Color.White;
        }

        private void CancelButton_MouseHover(object sender, EventArgs e)
        {
            CancelButton.BackColor = Color.LightGray;
        }

        private void CancelButton_MouseLeave(object sender, EventArgs e)
        {
            CancelButton.BackColor = Color.White;
        }
    }
}

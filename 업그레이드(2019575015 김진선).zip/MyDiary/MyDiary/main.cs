﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyDiary
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            button1.BackColor = Color.LightGray;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.White;
        }

        private void button2_MouseHover(object sender, EventArgs e)
        {
            button2.BackColor = Color.LightGray;
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            button2.BackColor = Color.White;
        }

        /*private void button3_MouseHover(object sender, EventArgs e)
        {
            button3.BackColor = Color.LightGray;
        }

        private void button3_MouseLeave(object sender, EventArgs e)
        {
            button3.BackColor = Color.White;
        }*/

        private void button4_MouseHover(object sender, EventArgs e)
        {
            button4.BackColor = Color.LightGray;
        }

        private void button4_MouseLeave(object sender, EventArgs e)
        {
            button4.BackColor = Color.White;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            add newForm = new add();
            newForm.Show();
            Program.ac.MainForm = newForm;
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            search newForm = new search();
            newForm.Show();
            Program.ac.MainForm = newForm;
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            update newForm = new update();
            newForm.Show();
            Program.ac.MainForm = newForm;
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            delete newForm = new delete();
            newForm.Show();
            Program.ac.MainForm = newForm;
            this.Close();
        }

        
    }
}

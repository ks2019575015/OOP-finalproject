﻿using System;
using System.Drawing;

using System.Windows.Forms;

namespace MyDiary
{
    public partial class start : Form
    {
        public start()
        {
            InitializeComponent();
        }

        

        private void LoginBox_Click(object sender, EventArgs e)
        {
            this.Hide();
            login newForm = new login();
            newForm.Show();
            Program.ac.MainForm = newForm;
            this.Close();
        }
        
        private void ExitBox_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void LoginBox_MouseHover(object sender, EventArgs e)
        {
            LoginBox.BackColor = Color.LightGray;
        }

        private void LoginBox_MouseLeave(object sender, EventArgs e)
        {
            LoginBox.BackColor = Color.White;
        }

        private void ExitBox_MouseHover(object sender, EventArgs e)
        {
            ExitBox.BackColor = Color.LightGray;           
        }

        private void ExitBox_MouseLeave(object sender, EventArgs e)
        {
            ExitBox.BackColor = Color.White;
        }
    }
}

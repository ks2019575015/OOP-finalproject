﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MyDiary
{
    public partial class delete : Form
    {
        MySqlConnection connection =
        new MySqlConnection("Server=localhost;Database=diary;Uid=root;Pwd=2019575015;");

        public DataTable GetDBTable(string sql)
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter(sql, connection);
            MySqlCommandBuilder builder = new MySqlCommandBuilder(adapter);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            return dt;
        }
        public delete()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection.Open();
            string sql = "select date, title, content from diary_tb where date = '" + this.dateBox.Text + "'";
            DataTable database = GetDBTable(sql);
            dataGridView1.DataSource = database;
            connection.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            string insertQuery = "delete from diary_tb where date = '" + this.dateBox.Text + "'"; 
            connection.Open();
            MySqlCommand command = new MySqlCommand(insertQuery, connection);

            try//예외 처리
            {
                if (command.ExecuteNonQuery() == 1) MessageBox.Show("삭제완료😉");
                else MessageBox.Show("오류😥");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            connection.Close();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            main newForm = new main();
            newForm.Show();
            Program.ac.MainForm = newForm;
            this.Close();
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            button1.BackColor = Color.LightGray;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.White;
        }

        private void button3_MouseHover(object sender, EventArgs e)
        {
            button3.BackColor = Color.LightGray;
        }

        private void button3_MouseLeave(object sender, EventArgs e)
        {
            button3.BackColor = Color.White;
        }

        private void button2_MouseHover(object sender, EventArgs e)
        {
            button2.BackColor = Color.LightGray;
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            button2.BackColor = Color.White;
        }
    }
}

﻿using System;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MyDiary
{
    public partial class update : Form
    {
        MySqlConnection connection =
        new MySqlConnection("Server=localhost;Database=diary;Uid=root;Pwd=2019575015;");

        public update()
        {
            InitializeComponent();
        }

        private void savebutton_Click(object sender, EventArgs e)
        {
            string insertQuery = "UPDATE diary_tb SET(date,title,content) VALUES('" + this.dateBox.Text + "','" + this.titleBox.Text + "','" + this.ContentBox.Text + "')";
            connection.Open();
            MySqlCommand command = new MySqlCommand(insertQuery, connection);

            try
            {
                if (command.ExecuteNonQuery() == 1) MessageBox.Show("수정완료😉");
                else MessageBox.Show("오류😥");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            connection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            main newForm = new main();
            newForm.Show();
            Program.ac.MainForm = newForm;
            this.Close();
        }

        private void savebutton_MouseHover(object sender, EventArgs e)
        {
            savebutton.BackColor = Color.LightGray;
        }

        private void savebutton_MouseLeave(object sender, EventArgs e)
        {
            savebutton.BackColor = Color.White;
        }

        private void button2_MouseHover(object sender, EventArgs e)
        {
            button2.BackColor = Color.LightGray;
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            button2.BackColor = Color.White;
        }
    }
}

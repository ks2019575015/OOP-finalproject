﻿
namespace MyDiary
{
    partial class start
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(start));
            this.LoginBox = new System.Windows.Forms.Button();
            this.ExitBox = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LoginBox
            // 
            this.LoginBox.BackColor = System.Drawing.Color.White;
            this.LoginBox.Font = new System.Drawing.Font("ImcreSoojin OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.LoginBox.Location = new System.Drawing.Point(353, 391);
            this.LoginBox.Name = "LoginBox";
            this.LoginBox.Size = new System.Drawing.Size(263, 79);
            this.LoginBox.TabIndex = 0;
            this.LoginBox.Text = "로그인";
            this.LoginBox.UseVisualStyleBackColor = false;
            this.LoginBox.Click += new System.EventHandler(this.LoginBox_Click);
            this.LoginBox.MouseLeave += new System.EventHandler(this.LoginBox_MouseLeave);
            this.LoginBox.MouseHover += new System.EventHandler(this.LoginBox_MouseHover);
            // 
            // ExitBox
            // 
            this.ExitBox.BackColor = System.Drawing.Color.White;
            this.ExitBox.Font = new System.Drawing.Font("ImcreSoojin OTF", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ExitBox.Location = new System.Drawing.Point(353, 491);
            this.ExitBox.Name = "ExitBox";
            this.ExitBox.Size = new System.Drawing.Size(263, 79);
            this.ExitBox.TabIndex = 1;
            this.ExitBox.Text = "종료";
            this.ExitBox.UseVisualStyleBackColor = false;
            this.ExitBox.Click += new System.EventHandler(this.ExitBox_Click);
            this.ExitBox.MouseLeave += new System.EventHandler(this.ExitBox_MouseLeave);
            this.ExitBox.MouseHover += new System.EventHandler(this.ExitBox_MouseHover);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("ImcreSoojin OTF", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(360, 218);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(256, 84);
            this.label1.TabIndex = 2;
            this.label1.Text = "DIARY";
            // 
            // start
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(978, 644);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ExitBox);
            this.Controls.Add(this.LoginBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "start";
            this.Text = "MyDiary";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button LoginBox;
        private System.Windows.Forms.Button ExitBox;
        private System.Windows.Forms.Label label1;
    }
}

